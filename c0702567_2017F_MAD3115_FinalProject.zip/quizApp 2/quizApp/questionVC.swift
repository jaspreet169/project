//
//  questionVC.swift
//  quizApp
//
//  Created by MacStudent on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class questionVC: UIViewController {
    
    //var dictRoot = [Int: Dictionary<String, Any>]()  // 1   : "Ques" , Answers
    // var dictionaryQ = [String:Array<String>]()
   // var array1 = [String]()
   /// var dictQ1 = [Int: Dictionary<String, Any>]()
    
    
    var seconds:Int = 10
    var timer = Timer()
    
    
    
    var correctAnswers = 0
    var wrongAnswer = 0

   var dictOfQuestion = [Int:String]()
    var questionNo = 1
    var answer = ["ans 1","ans 2","ans 3"," ans 4"]
    
     // var dictionary1 :[String:String] = Questiondict[1]!
    //  print(Questiondict.description)
    // print(dictionary1.description)
    // print(dictionary1["question"]!)
    

    
    var Questiondict = [ 1:["question" :"Full Form of OS is?",
                            "ans 1":"Order of Significance",
                            "ans 2":"Operating system",
                            "ans 3":"Open software",
                            "ans 4": "Optical Sensor",
                            "correctans":"Operating system"],
                         2: ["question" : "The ribbon is used in ?",
                             "ans 1":"Laser Printer",
                             "ans 2":"Plotter",
                             "ans 3":"Ink-jet printer" ,
                             "ans 4":"Dot Matrix printer" ,
                             "correctans" :"Dot Matrix printer"],
                         
                         3 : ["question":"Main memory is also known as ?",
                              "ans 1": "Auxiliary memory",
                              "ans 2":"Primery memory",
                              "ans 3":"Secondry memory" ,
                              "ans 4": "None of above",
                              "correctans" :"Primery memory"],
        
           4 : ["question":"A DNS translates a domain name into what ?",
             "ans 1": "Binary",
             "ans 2":"Hex",
             "ans 3":"IP" ,
             "ans 4": "URL",
             "correctans" :"IP"],
           
           5: ["question":"Which of the following is essential component of communication cycle ?",
                "ans 1": "A message",
                "ans 2": "An interpreter",
                "ans 3": "An email account" ,
                "ans 4": "An internet connection",
                "correctans" :"A message"],
           
           6 : ["question":"What does SSL stands for ?",
                "ans 1": "System socket layer",
                "ans 2":"Secure system login",
                "ans 3":"Secure socket layer" ,
                "ans 4": "Secure system login",
                "correctans" :"Secure socket layer"],
           
           7 : ["question":"What does PPTP stand for ?",
                "ans 1": "Point to Point Transmission Protocol",
                "ans 2":"Point to Point Transfer Protocol",
                "ans 3":"Point to Point Tunneling Protocol" ,
                "ans 4": "Point to Point Traffic Protocol",
                "correctans" :"Point to Point Tunneling Protocol"],
           
           8 : ["question":"Which country created the most used networking software in 1980's ?",
                "ans 1": "Sun",
                "ans 2":"IBM",
                "ans 3":"Novell" ,
                "ans 4": "Microsoft",
                "correctans" :"Novell"],
           
           9: ["question":"Which American computer company is called Big Blue ?",
                "ans 1": "IBM",
                "ans 2":"Compaq Corp",
                "ans 3":"Microsoft" ,
                "ans 4": "Tandy Svenson",
                "correctans" :"IBM"],
           
           10 : ["question":"What is MAC ?",
                "ans 1": "A computer made by Apple",
                "ans 2":"Memory address corruption",
                "ans 3":"Mediocre Apple Computer" ,
                "ans 4": "Media Access Control",
                "correctans" :"Media Access Control"]
        
    ]
    
    
    

    

    @IBOutlet weak var lblTimer: UILabel!
    
    
    
    
    
    
    
    
    @IBOutlet weak var progress: UIProgressView!
    
    
    @IBOutlet weak var lblQuestion: UILabel!
    
    
   
    @IBOutlet weak var btnAnswer1: UIButton!
    
   
    @IBOutlet weak var btnAnswer2: UIButton!
    
    
    @IBOutlet weak var btnAnswer3: UIButton!
    
    @IBOutlet weak var btnAnswer4: UIButton!
    
    
    @IBOutlet weak var btnNext: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        getdata()
        
   }
    
    func startTimer () {
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(questionVC.updateTimer), userInfo: nil, repeats: true)
    }
    
    
    func getdata() {
    if( questionNo <= Questiondict.count)
    {
        lblQuestion.text = (Questiondict[questionNo]!["question"])
        btnAnswer1.setTitle(Questiondict[questionNo]!["ans 1"], for: .normal)
        btnAnswer2.setTitle(Questiondict[questionNo]!["ans 2"], for: .normal)
        btnAnswer3.setTitle(Questiondict[questionNo]!["ans 3"], for: .normal)
        btnAnswer4.setTitle(Questiondict[questionNo]!["ans 4"], for: .normal)
        
       seconds = 10
        startTimer()
        
        //for i in 0...9
        //var dictionary1 :[String:String] = Questiondict[RandomArray[i]]!
        
        }
    else
    {
        print("questions finished")
        
        

        performSegue(withIdentifier: "ShowScoreVC", sender: self)
        
    }
    }
    
       //print(dictionary1["correctans"]!)
        
        
       // var Ans1 = dictionary1["ans 1"]

    
        
    
      override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let scrvc = segue.destination as! scoreVC
        
        scrvc.correctAnswer = correctAnswers
        scrvc.wrongAnswer = wrongAnswer
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    @IBAction func btnAnswer1(_ sender: UIButton) {
        
         
            if (Questiondict[questionNo]!["correctans"] == btnAnswer1.titleLabel?.text){
              print("yes")
            correctAnswers += 1
            
        }else {
            print("wrong")
            wrongAnswer += 1
            
        }
        }
    
    
    @IBAction func btnAnswer2(_ sender: UIButton) {
        
        if (Questiondict[questionNo]!["correctans"] == btnAnswer2.titleLabel?.text){
            
            correctAnswers += 1
            
        }else {
            
            wrongAnswer += 1
            
        }
        
     }
        
    
    
    @IBAction func btnAnswer3(_ sender: UIButton) {
        
        if (Questiondict[questionNo]!["correctans"] == btnAnswer3.titleLabel?.text){
            
            correctAnswers += 1
            
        }else {
            
            wrongAnswer += 1
            
        }

        
    }
        
    
    

    @IBAction func btnAnswer4(_ sender: UIButton) {
        
        if (Questiondict[questionNo]!["correctans"] == btnAnswer4.titleLabel?.text){
            print("yes")
            correctAnswers += 1
            
        }else {
            print("wrong")
            wrongAnswer += 1
            
        }

       
        
    }
    
   // @objc func counter()
    //{
     //   seconds -= 1
      //  lblTimer.text = String(seconds)
        
      //  if(seconds == 0)
       // {
       //      timer.invalidate()
       // }
        
    //}
    
    @objc func updateTimer()
    {
        seconds -= 1
        if(seconds == 0)
        {
            lblTimer.text = ""
            seconds = 10
            //color normal
            lblTimer.textColor = #colorLiteral(red: 0.2196078449, green: 0.007843137719, blue: 0.8549019694, alpha: 1)
            timer.invalidate()
        }
        else if (seconds == 5)
        {
            // color red
            lblTimer.textColor = #colorLiteral(red: 0.7450980544, green: 0.1568627506, blue: 0.07450980693, alpha: 1)
        }

        
//        else if(seconds < 0)
//        {
//             //timer.invalidate()
//            //lblTimer.text = ""
//        }
        lblTimer.text = "Timer: " + String(seconds) + "sec"
    }
    
    
    
    
    
    @IBAction func btnNext(_ sender: UIButton) {
        
       
        
        
          progress.progress = Float(questionNo)/10
        print("correct answers : \(correctAnswers)")
        
         print("wrong answers : \(wrongAnswer)")
        questionNo = questionNo + 1
       

        
      getdata()
        
       
    }
    
    
    
}


