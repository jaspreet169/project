//
//  question.swift
//  quizApp
//
//  Created by MacStudent on 2017-10-25.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation
class  Question {
    
    
    
    var questionNo : Int!
    var question : String!
    var ans1: String!
    var ans2: String!
    var ans3: String!
    var ans4: String!
    var correctans : String
    
    
     static var CorrectAnswer = [String]()
      static var questionList = [Question]()
     static var right_ans = 0
      static  var wrong_ans = 0
    
    
    
    
    init ()
    {
        self .questionNo = 0
        self.question = ""
        self.ans1 = ""
        self.ans2 = ""
        self.ans3 = ""
        self.ans4 = ""
        self.correctans = " "
    }
    
    init(questionNo:Int ,question :String , ans1: String, ans2:String, ans3:String, ans4:String, correctans: String)  {
        
        self.questionNo = questionNo
        self.question = question
        self.ans1 = ans1
        self.ans2 = ans2
        self.ans3 = ans3
     self.ans4 = ans4
     self.correctans = correctans
        
    }
    
    
      static  func question(question:Question) {
          if questionList[question.questionNo] == nil {
          questionList[question.questionNo] = question

    }
    
}
    
    
    static func  checkAnswer ()
    {
       for i in 0...9 {
            if  questionList[i].correctans == CorrectAnswer[i]{
              right_ans +=  1
            }
            
         else {
               wrong_ans += 1
       }
        
        }

    }
    
    }


