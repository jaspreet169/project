//
//  questionVC.swift
//  quizApp
//
//  Created by MacStudent on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class questionVC: UIViewController {
    
    //var dictRoot = [Int: Dictionary<String, Any>]()  // 1   : "Ques" , Answers
    // var dictionaryQ = [String:Array<String>]()
   // var array1 = [String]()
   /// var dictQ1 = [Int: Dictionary<String, Any>]()
    var seconds:Int = 10
    var timer = Timer()
    
    
    
    var coorectAnswers = 0
    var wrongAnswer = 0

   var dictOfQuestion = [Int:String]()
    var questionNo = 1
    var answer = ["ans 1","ans 2","ans 3"," ans 4"]
    
    // var dictionary1 :[String:String] = Questiondict[1]!
  
    //  print(Questiondict.description)
  
    // print(dictionary1.description)
  
    // print(dictionary1["question"]!)
    

    
    var Questiondict = [ 1:["question" :"what is your fav color?",
                            "ans 1":"blue",
                            "ans 2":"pink",
                            "ans 3":"black",
                            "ans 4": "yellow",
                            "correctans":"pink"
        ],
                         2: ["question" : "choose pet!!",
                             "ans 1":"cat",
                             "ans 2":"bird",
                             "ans 3":"dog" ,
                             "ans 4":"rabbit" ,
                             "correctans" :"dog"
        ],
                         3 : ["question":"which phone you are using?",
                              "ans 1": "iphone",
                              "ans 2":"vivo",
                              "ans 3":"samsung" ,
                              "ans 4": "oppo",
                              "correctans" :"oppo"],
        
        4 : ["question":"choose letter!!!!",
             "ans 1": "ABC",
             "ans 2":"BIN",
             "ans 3":"POI" ,
             "ans 4": "BGT",
             "correctans" :"ABC"]
        
    ]
    
    
    

    

    @IBOutlet weak var lblTimer: UILabel!
    
    
    
    
    
    
    
    
    @IBOutlet weak var progress: UIProgressView!
    
    
    @IBOutlet weak var lblQuestion: UILabel!
    
    
   
    @IBOutlet weak var btnAnswer1: UIButton!
    
   
    @IBOutlet weak var btnAnswer2: UIButton!
    
    
    @IBOutlet weak var btnAnswer3: UIButton!
    
    @IBOutlet weak var btnAnswer4: UIButton!
    
    
    @IBOutlet weak var btnNext: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
        
        //timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(questionVC.counter), userInfo: nil, repeats: true)
        
        
       getdata()
        
       
        
        
    }
    
    func startTimer () {
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(questionVC.updateTimer), userInfo: nil, repeats: true)
    }
    
    
    
    
    
     
   func getdata() {
    if( questionNo <= Questiondict.count)
    {
        lblQuestion.text = (Questiondict[questionNo]!["question"])
        btnAnswer1.setTitle(Questiondict[questionNo]!["ans 1"], for: .normal)
        btnAnswer2.setTitle(Questiondict[questionNo]!["ans 2"], for: .normal)
        btnAnswer3.setTitle(Questiondict[questionNo]!["ans 3"], for: .normal)
        btnAnswer4.setTitle(Questiondict[questionNo]!["ans 4"], for: .normal)
        
       seconds = 10
        startTimer()
        
        //for i in 0...9
        //var dictionary1 :[String:String] = Questiondict[RandomArray[i]]!
        
        }
    else
    {
        print("questions finished")
        
             let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
    
        
        
                let VC = storyBoard.instantiateViewController(withIdentifier: "scoreVC") as!  scoreVC
        
    
        
        self.present(VC, animated: true, completion: nil)
        
        
        
    }
    }
    
       //print(dictionary1["correctans"]!)
        
        
       // var Ans1 = dictionary1["ans 1"]

    
        
    
      override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let scrvc = segue.destination as! scoreVC
        
        scrvc.correctAnswer = coorectAnswers
        scrvc.wrongAnswer = wrongAnswer
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    @IBAction func btnAnswer1(_ sender: UIButton) {
        
         
            if (Questiondict[questionNo]!["correctans"] == btnAnswer1.titleLabel?.text){
              print("yes")
            coorectAnswers += 1
            
        }else {
            print("wrong")
            wrongAnswer += 1
            
        }
        
        
        
        
//       let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
//        
//        let VC = storyBoard.instantiateViewController(withIdentifier: "questionVC") as!  questionVC
//        self.present(VC, animated: true, completion: nil)
        
       
    
//    var answer = btnAnswer1.titleLabel?.text
//        if(answer?.isEmpty)
        
        
    }
    
    
    @IBAction func btnAnswer2(_ sender: UIButton) {
        
        if (Questiondict[questionNo]!["correctans"] == btnAnswer2.titleLabel?.text){
            
            coorectAnswers += 1
            
        }else {
            
            wrongAnswer += 1
            
        }
        
//
//        let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
//
//        let VC = storyBoard.instantiateViewController(withIdentifier: "questionVC") as!  questionVC
//        self.present(VC, animated: true, completion: nil)
        
        
       
        
    }
        
    
    
    @IBAction func btnAnswer3(_ sender: UIButton) {
        
        if (Questiondict[questionNo]!["correctans"] == btnAnswer3.titleLabel?.text){
            
            coorectAnswers += 1
            
        }else {
            
            wrongAnswer += 1
            
        }
        
//        let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
//
//        let VC = storyBoard.instantiateViewController(withIdentifier: "questionVC") as!  questionVC
//        self.present(VC, animated: true, completion: nil)
        
        
    }
        
    
    

    @IBAction func btnAnswer4(_ sender: UIButton) {
        
        if (Questiondict[questionNo]!["correctans"] == btnAnswer4.titleLabel?.text){
            print("yes")
            coorectAnswers += 1
            
        }else {
            print("wrong")
            wrongAnswer += 1
            
        }
        
//        let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
//
//        let VC = storyBoard.instantiateViewController(withIdentifier: "questionVC") as!  questionVC
//        self.present(VC, animated: true, completion: nil)
        
       
        
    }
    
   // @objc func counter()
    //{
     //   seconds -= 1
      //  lblTimer.text = String(seconds)
        
      //  if(seconds == 0)
       // {
       //      timer.invalidate()
       // }
        
    //}
    
    @objc func updateTimer() {
        seconds -= 1
        if(seconds == 0){
            lblTimer.text = ""
           timer.invalidate()
        }
            
        else if(seconds < 0){
             //timer.invalidate()
            //lblTimer.text = ""
        }
        lblTimer.text = "Timer: " + String(seconds) + "sec"
    }
    
    
    
    
    
    @IBAction func btnNext(_ sender: UIButton) {
        
       
        
        
          progress.progress = Float(questionNo)/10
        print("correct answers : \(coorectAnswers)")
        
         print("wrong answers : \(wrongAnswer)")
        questionNo = questionNo + 1
       
//
        
//                let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
//
//                let VC = storyBoard.instantiateViewController(withIdentifier: "questionVC") as!  questionVC
//                self.present(VC, animated: true, completion: nil)
        
      getdata()
        
       
    }
    
    
    
}


