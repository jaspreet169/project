//
//  questionVC.swift
//  quizApp
//
//  Created by MacStudent on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class questionVC: UIViewController {
    
    //var dictRoot = [Int: Dictionary<String, Any>]()  // 1   : "Ques" , Answers
    // var dictionaryQ = [String:Array<String>]()
   // var array1 = [String]()
   /// var dictQ1 = [Int: Dictionary<String, Any>]()
   

   var dictOfQuestion = [Int:String]()
    var questionNo = 1
    var answer = ["ans 1","ans 2","ans 3"," ans 4"]   // var dictionary1 :[String:String] = Questiondict[1]!
  //  print(Questiondict.description)
  // print(dictionary1.description)
  // print(dictionary1["question"]!)

    
    var Questiondict = [ 1:["question" :"what is your fav color?",
                            "ans 1":"blue",
                            "ans 2":"pink",
                            "ans 3":"black",
                            "ans 4": "yellow",
                            "correctans":"ans 2"
        ],
                         2: ["question" : "choose pet!!",
                             "ans 1":"cat",
                             "ans 2":"bird",
                             "ans 3":"dog" ,
                             "ans 4":"rabbit" ,
                             "correctans" :"ans 3"
        ],
                         3 : ["question":"which phone you are using?",
                              "ans 1": "iphone",
                              "ans 2":"vivo",
                              "ans 3":"samsung" ,
                              "ans 4": "oppo",
                              "correctans" :"ans 4"]
    ]
    
    
    
    
    
    
    
    
    
    
    
    @IBOutlet weak var progress: UIProgressView!
    
    
    @IBOutlet weak var lblQuestion: UILabel!
    
    
   
    @IBOutlet weak var btnAnswer1: UIButton!
    
   
    @IBOutlet weak var btnAnswer2: UIButton!
    
    
    @IBOutlet weak var btnAnswer3: UIButton!
    
    @IBOutlet weak var btnAnswer4: UIButton!
    
    
    @IBOutlet weak var btnNext: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       getdata()
        
        
    }
      
     
   func getdata() {
        
        lblQuestion.text = (Questiondict[questionNo]!["question"])
        btnAnswer1.setTitle(Questiondict[questionNo]!["ans 1"], for: .normal)
        btnAnswer2.setTitle(Questiondict[questionNo]!["ans 2"], for: .normal)
        btnAnswer3.setTitle(Questiondict[questionNo]!["ans 3"], for: .normal)
        btnAnswer4.setTitle(Questiondict[questionNo]!["ans 4"], for: .normal)
        //for i in 0...9
        //var dictionary1 :[String:String] = Questiondict[RandomArray[i]]!
        
        }
    
    
       //print(dictionary1["correctans"]!)
        
        
       // var Ans1 = dictionary1["ans 1"]

        
    
      override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    @IBAction func btnAnswer1(_ sender: UIButton) {
       let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
        
        let VC = storyBoard.instantiateViewController(withIdentifier: "questionVC") as!  questionVC
        self.present(VC, animated: true, completion: nil)
        
        //let menuVC : UIStoryboard = storyboard!.instantiateViewControllerWithIdentifier("questionVC") as! questionVC
       // menuVC.btnMenu = sender
    }
    
    
    @IBAction func btnAnswer2(_ sender: UIButton) {
        
        //let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
        
        //let VC = storyBoard.instantiateViewController(withIdentifier: "") as!  instructionVC
        //self.present(VC, animated: true, completion: nil)
        
        
        
    }
    
    @IBAction func btnAnswer3(_ sender: UIButton) {
        
        //let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
        
       // let VC = storyBoard.instantiateViewController(withIdentifier: "") as!  instructionVC
        //self.present(VC, animated: true, completion: nil)
        
        
    }
    

    @IBAction func btnAnswer4(_ sender: UIButton) {
        
        
       // let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
        
        ///let VC = storyBoard.instantiateViewController(withIdentifier: "") as!  instructionVC
        //self.present(VC, animated: true, completion: nil)
        
    }
    
    
    @IBAction func btnNext(_ sender: UIButton) {
        
          //progress.progress = Float(Int(progress.value)/100)
        questionNo = questionNo + 1
         getdata()
        
    }
    
    
    
}


