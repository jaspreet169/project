//
//  ViewController.swift
//  quizApp
//
//  Created by MacStudent on 2017-10-23.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tfUserName: UITextField!
    
    @IBOutlet weak var tfPassword: UITextField!
    
    @IBOutlet weak var btnLogin: UIButton!
    
    
 
    
    @IBOutlet weak var btnNewUser: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func segue() {
        
        
        
        
        
        let storyBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let empVC = storyBoard.instantiateViewController(withIdentifier: "deskBoardVC") as!  deskBoardVC
        
        self.present(empVC, animated: true, completion: nil)
        
    }
    

    
    
    
    
    @IBAction func btnLogin(_ sender: UIButton) {

        if (tfUserName.text  == "xyz" && tfPassword.text == "123") || (tfUserName.text  == "c0702567" && tfPassword.text == "jaspreet")        {
            let alert = UIAlertController(title: "Alert", message: "welcome", preferredStyle: .alert)
            let cancelAction = UIAlertAction(title: "ok", style: .default, handler: {action in self.segue( )})
            alert.addAction(cancelAction)
            self.present(alert,animated: true,completion: nil)
        }
       else{
           let alert = UIAlertController(title: "Alert", message: "Password is incorrect", preferredStyle: .alert)
           let action = UIAlertAction(title: "ok", style: .destructive, handler: nil)
           alert.addAction(action)
           self.present(alert,animated: true,completion: nil)
       }
        
    }
    
    
   
}

