//
//  deskBoardVC.swift
//  quizApp
//
//  Created by MacStudent on 2017-10-23.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class deskBoardVC: UIViewController {
    
    
    @IBOutlet weak var lbldeskBoard: UILabel!
    

    @IBOutlet weak var textField: UITextView!
    
    @IBOutlet weak var btnStart: UIButton!
    
    
    @IBOutlet weak var btnInstruction: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func btnStart(_ sender: UIButton) {
        
        let alert = UIAlertController(title: "Start Quiz", message: "All the best!", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "ok", style: .default, handler: nil)
        alert.addAction(cancelAction)
        self.present(alert,animated: true,completion: nil)
        
    }
    
    
    
    @IBAction func btnInstruction(_ sender: UIButton) {
            
            let storyBoard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: nil)
            
            let VC = storyBoard.instantiateViewController(withIdentifier: "instructionVC") as!  instructionVC
            self.present(VC, animated: true, completion: nil)
            
        
        
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
